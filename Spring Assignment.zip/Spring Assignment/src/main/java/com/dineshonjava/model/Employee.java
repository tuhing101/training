package com.dineshonjava.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="Employee")
public class Employee implements Serializable{

	 
	
	@Id
	 
	@Column(name = "customerid")
	private Integer customerId;
	
	@Column(name="customername")
	private String customerName;
	
	@Column(name="customeraddress")
	private String customerAddress;
	
	@Column(name="customerphoneno")
	private String customerPhoneno;
	
	@Column(name="customeremail")
	private String customerEmail;
	
	@Column(name="customercompanyname")
	private String customerCompanyname;
	
	@Column(name="customerAge")
	private Integer customerAge;
	
	@Column(name="customerbalance")
	private String customerBalance;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getCustomerPhoneno() {
		return customerPhoneno;
	}

	public void setCustomerPhoneno(String customerPhoneno) {
		this.customerPhoneno = customerPhoneno;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public String getCustomerCompanyname() {
		return customerCompanyname;
	}

	public void setCustomerCompanyname(String customerCompanyname) {
		this.customerCompanyname = customerCompanyname;
	}

	public Integer getCustomerAge() {
		return customerAge;
	}

	public void setCustomerAge(Integer customerAge) {
		this.customerAge = customerAge;
	}

	public String getCustomerBalance() {
		return customerBalance;
	}

	public void setCustomerBalance(String customerBalance) {
		this.customerBalance = customerBalance;
	}

	
}
